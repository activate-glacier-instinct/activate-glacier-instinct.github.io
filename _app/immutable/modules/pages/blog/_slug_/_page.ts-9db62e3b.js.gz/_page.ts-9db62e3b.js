import{l,p as o,t as p}from"../../../../chunks/_page-895705b0.js";import"../../../../chunks/data-7dcbf126.js";export{l as load,o as prerender,p as trailingSlash};
