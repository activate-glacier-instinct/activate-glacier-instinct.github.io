import{default as t}from"../components/pages/_page.svelte-5daa7b53.js";export{t as component};
