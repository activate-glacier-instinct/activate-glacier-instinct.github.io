import{_ as r}from"./_page-10a903a4.js";import{default as t}from"../components/pages/blog/_slug_/_page.svelte-cc55d0fb.js";export{t as component,r as universal};
