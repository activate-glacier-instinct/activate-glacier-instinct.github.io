import{default as t}from"../components/error.svelte-d1950734.js";export{t as component};
