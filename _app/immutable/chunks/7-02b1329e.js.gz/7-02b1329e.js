import{default as t}from"../components/pages/work/_page.svelte-3823aad9.js";export{t as component};
