import{default as t}from"../components/layout.svelte-cd8f1078.js";export{t as component};
