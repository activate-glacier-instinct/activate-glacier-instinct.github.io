import{default as t}from"../components/pages/1hdoc/_page.svelte-61161454.js";export{t as component};
