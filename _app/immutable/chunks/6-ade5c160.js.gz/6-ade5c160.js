import{_ as r}from"./_page-f166f8de.js";import{default as t}from"../components/pages/blog/100days-of-code/_slug_/_page.svelte-f7265731.js";export{t as component,r as universal};
