import{default as t}from"../components/pages/_page.svelte-fed1a7f7.js";export{t as component};
