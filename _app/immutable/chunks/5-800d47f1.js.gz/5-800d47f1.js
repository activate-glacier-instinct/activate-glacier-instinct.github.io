import{default as t}from"../components/pages/work/_page.svelte-8f820f3f.js";export{t as component};
