import{_ as r}from"./_page-9b360380.js";import{default as t}from"../components/pages/blog/_slug_/_page.svelte-f6fdf54b.js";export{t as component,r as universal};
