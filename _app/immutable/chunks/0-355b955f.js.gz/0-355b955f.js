import{default as t}from"../components/pages/_layout.svelte-7e12b633.js";const e=!0;export{t as component,e as server};
