import{default as t}from"../components/pages/_page.svelte-e1f0ea59.js";export{t as component};
