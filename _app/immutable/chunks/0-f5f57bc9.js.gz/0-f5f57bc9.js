import{default as t}from"../components/pages/_layout.svelte-91a4204a.js";const e=!0;export{t as component,e as server};
