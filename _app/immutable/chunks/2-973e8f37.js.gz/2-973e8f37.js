import{_ as r}from"./_layout-11cc11fd.js";import{default as t}from"../components/pages/blog/_layout.svelte-d783a918.js";export{t as component,r as universal};
