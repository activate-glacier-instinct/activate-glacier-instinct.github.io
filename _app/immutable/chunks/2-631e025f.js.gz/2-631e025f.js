import{default as t}from"../components/pages/_page.svelte-0e6e8317.js";export{t as component};
