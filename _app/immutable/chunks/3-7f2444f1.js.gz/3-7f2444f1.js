import{default as t}from"../components/pages/1hdoc/_page.svelte-ecbcf4b7.js";export{t as component};
