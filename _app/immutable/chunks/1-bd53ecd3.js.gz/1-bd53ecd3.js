import{default as t}from"../components/error.svelte-8e974c28.js";export{t as component};
