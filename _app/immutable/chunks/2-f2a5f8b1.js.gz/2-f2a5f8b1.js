import{default as t}from"../components/pages/_page.svelte-ea661338.js";export{t as component};
