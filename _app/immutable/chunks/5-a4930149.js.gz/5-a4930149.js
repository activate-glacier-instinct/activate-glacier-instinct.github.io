import{_ as r}from"./_page-8918611c.js";import{default as t}from"../components/pages/blog/_page.svelte-10cc50e7.js";export{t as component,r as universal};
