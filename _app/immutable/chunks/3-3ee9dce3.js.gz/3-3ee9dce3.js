import{default as t}from"../components/pages/_page.svelte-b4553a0b.js";export{t as component};
