import{_ as r}from"./_page-faa78b02.js";import{default as t}from"../components/pages/blog/100days-of-code/_page.svelte-523139c9.js";export{t as component,r as universal};
