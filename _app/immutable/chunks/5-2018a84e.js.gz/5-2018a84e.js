import{_ as r}from"./_page-895705b0.js";import{default as t}from"../components/pages/blog/_slug_/_page.svelte-73be4ed4.js";export{t as component,r as universal};
