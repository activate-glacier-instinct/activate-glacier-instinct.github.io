import{default as t}from"../components/error.svelte-cacf9582.js";export{t as component};
