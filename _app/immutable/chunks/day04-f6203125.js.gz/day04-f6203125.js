const n={},o=`<h1>100 Days Of Code - Log</h1>
<p>================</p>
<h2>Day 4</h2>
<p>Date: 10/01/23</p>
<p>================</p>
<blockquote>
<p>Goal: make a simple portfolio + blog site using SvelteKit for my anon account</p>
</blockquote>
<h3><strong>Today's Progress</strong>:</h3>
<ul>
<li>Learned about <a href="https://pnpm.io/">pnpm</a>
<ul>
<li>Checked out comparisons between yarn, npm, and pnpm</li>
<li>Amazing comparison here https://www.youtube.com/watch?v=kVJ0yoXCORE</li>
</ul>
</li>
<li>Implemented p5 on the homepage</li>
<li>Tried a few p5 animations and ended up adding a little scan line animation</li>
</ul>
<h3><strong>Thoughts</strong>:</h3>
<ul>
<li>A bit slower today, but still good progress</li>
</ul>
<h3><strong>Link to work:</strong></h3>
<ul>
<li><a href="https://github.com/activate-glacier-instinct/activate-glacier-instinct.github.io">Portfolio - Repo</a></li>
<li><a href="https://activate-glacier-instinct.github.io/">Portfolio - Deployment</a></li>
<li><a href="https://www.figma.com/file/EACX3PwCLrEc2q3oHRtxU4/Portfolio---Moodboard?node-id=0%3A1">Portfolio - Design Moodboard</a></li>
</ul>
`;export{n as attributes,o as html};
