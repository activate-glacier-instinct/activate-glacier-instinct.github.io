import{default as t}from"../components/pages/_page.svelte-f065eb0a.js";export{t as component};
