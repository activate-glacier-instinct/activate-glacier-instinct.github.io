import{default as t}from"../components/error.svelte-f2b5a72c.js";export{t as component};
