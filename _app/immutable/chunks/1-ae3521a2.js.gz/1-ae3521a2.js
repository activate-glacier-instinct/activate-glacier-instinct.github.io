import{default as t}from"../components/error.svelte-4146393d.js";export{t as component};
