const t=[{title:"test1",body:"this is the first test blog post"},{title:"test2",body:"this is the second test blog post"}];export{t as b};
