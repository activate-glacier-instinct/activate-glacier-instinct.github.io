import{default as t}from"../components/pages/_layout.svelte-e26abada.js";const e=!0;export{t as component,e as server};
