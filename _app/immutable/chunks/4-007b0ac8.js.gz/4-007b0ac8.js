import{_ as r}from"./_page-49d091ce.js";import{default as t}from"../components/pages/blog/_page.svelte-be32298a.js";export{t as component,r as universal};
