import{default as t}from"../components/pages/_page.svelte-ea5de2aa.js";export{t as component};
