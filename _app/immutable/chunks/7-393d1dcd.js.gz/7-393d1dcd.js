import{_ as r}from"./_page-27871e2e.js";import{default as t}from"../components/pages/work/_page.svelte-87e8fef4.js";export{t as component,r as universal};
