import{_ as r}from"./_page-3972d3ae.js";import{default as t}from"../components/pages/blog/_page.svelte-228bbd54.js";export{t as component,r as universal};
