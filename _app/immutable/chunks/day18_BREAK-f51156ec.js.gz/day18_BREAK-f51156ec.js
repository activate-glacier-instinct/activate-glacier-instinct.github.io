const t={},o=`<h2>Day 18/100</h2>
<hr>
<p>Date: 24/01/23</p>
<hr>
<h3>Goal:</h3>
<p>Make a simple portfolio + blog site using SvelteKit for my anon account</p>
<h3><strong>Today's Progress</strong>:</h3>
<ul>
<li>BREAK</li>
<li>Allowing for up to 2days break every fortnight. Planning to take both days.</li>
</ul>
<h3><strong>Next</strong>:</h3>
<ul>
<li>Improve the /work page with better content and examples</li>
</ul>
<h3><strong>Link to work:</strong></h3>
<ul>
<li><a href="https://github.com/activate-glacier-instinct/activate-glacier-instinct.github.io">Portfolio - Repo</a></li>
<li><a href="https://activate-glacier-instinct.github.io/">Portfolio - Deployment</a></li>
<li><a href="https://www.figma.com/file/EACX3PwCLrEc2q3oHRtxU4/Portfolio---Moodboard?node-id=0%3A1">Portfolio - Design Moodboard</a></li>
</ul>
`;export{t as attributes,o as html};
