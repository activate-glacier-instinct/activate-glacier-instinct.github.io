import{default as t}from"../components/pages/_layout.svelte-72c7c46c.js";const e=!0;export{t as component,e as server};
