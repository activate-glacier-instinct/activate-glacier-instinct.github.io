import{default as t}from"../components/pages/_page.svelte-b83faf2c.js";export{t as component};
