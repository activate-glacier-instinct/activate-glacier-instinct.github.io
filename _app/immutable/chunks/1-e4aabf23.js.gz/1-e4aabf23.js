import{default as t}from"../components/error.svelte-a9207635.js";export{t as component};
