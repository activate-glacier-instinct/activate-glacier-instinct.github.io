import{default as t}from"../components/pages/work/_page.svelte-d4353b6d.js";export{t as component};
