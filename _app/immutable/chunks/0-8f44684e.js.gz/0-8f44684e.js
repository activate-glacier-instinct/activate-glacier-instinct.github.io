import{_ as r}from"./_layout-79cb23d1.js";import{default as t}from"../components/pages/_layout.svelte-29de8424.js";export{t as component,r as universal};
