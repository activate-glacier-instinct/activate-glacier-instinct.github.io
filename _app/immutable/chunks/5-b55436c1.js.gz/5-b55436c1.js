import{_ as r}from"./_page-18976a4b.js";import{default as t}from"../components/pages/blog/_page.svelte-8cf5f786.js";export{t as component,r as universal};
