import{default as t}from"../components/pages/blog/_page.svelte-dbd66b6c.js";export{t as component};
