import{_ as r}from"./_page-f6128571.js";import{default as t}from"../components/pages/blog/100days-of-code/_page.svelte-7aac12db.js";export{t as component,r as universal};
