const o={},t=`<h2>Day 13/100</h2>
<hr>
<p>Date: 19/01/23</p>
<hr>
<h3>Goal:</h3>
<p>Make a simple portfolio + blog site using SvelteKit for my anon account</p>
<h3><strong>Today's Progress</strong>:</h3>
<ul>
<li>Adds <code>vite-markdown-preprocessor</code> and configuration</li>
<li>Adds functionality on <code>/blog/[slug]</code> for rendering the files from the data git submodules</li>
<li>Fix: removed a lot of redundant code</li>
</ul>
<h3><strong>Thoughts</strong>:</h3>
<ul>
<li>Looks terrible, but I can defo start styling again tomorrow</li>
</ul>
<h3><strong>Next</strong>:</h3>
<ul>
<li>Style <code>/blog/[slug]</code></li>
</ul>
<h3><strong>Link to work:</strong></h3>
<ul>
<li><a href="https://github.com/activate-glacier-instinct/activate-glacier-instinct.github.io">Portfolio - Repo</a></li>
<li><a href="https://activate-glacier-instinct.github.io/">Portfolio - Deployment</a></li>
<li><a href="https://www.figma.com/file/EACX3PwCLrEc2q3oHRtxU4/Portfolio---Moodboard?node-id=0%3A1">Portfolio - Design Moodboard</a></li>
</ul>
`;export{o as attributes,t as html};
